# Events []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/events.md)

---

## Basic events

Eventos de la tabla. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="500" data-src="http://jsfiddle.net/wenyi/e3nk137y/36/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## Column events

Use las opciones de columna `formatter`, `events` para definir los eventos customizables. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="500" data-src="http://jsfiddle.net/wenyi/e3nk137y/39/embedded/html,js,css,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

