(function () {
    var global = this,
        require = function() { return global.moment; },
        exports = global.NPM_TESTS = {};
